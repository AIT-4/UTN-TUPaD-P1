# Crear un programa que imprima por pantalla el mensaje: “Hola Mundo!”.

print("Hola Mundo!")