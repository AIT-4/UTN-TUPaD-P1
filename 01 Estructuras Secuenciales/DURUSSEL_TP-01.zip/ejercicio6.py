# Crear un programa que pida al usuario un número e imprima por pantalla la tabla de
# multiplicar de dicho número.

print("TABLA DE MULTIPLICAR")

# Pedimos al usuario un numero para formar la tabla
numero = int(input("Ingrese un numero entero: "))

# Imprimimos la tabla
print(f"{numero} x 1 = {numero * 1}")
print(f"{numero} x 2 = {numero * 2}")
print(f"{numero} x 3 = {numero * 3}")
print(f"{numero} x 4 = {numero * 4}")
print(f"{numero} x 5 = {numero * 5}")
print(f"{numero} x 6 = {numero * 6}")
print(f"{numero} x 7 = {numero * 7}")
print(f"{numero} x 8 = {numero * 8}")
print(f"{numero} x 9 = {numero * 9}")
